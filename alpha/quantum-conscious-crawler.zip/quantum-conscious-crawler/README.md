# Quantum-Conscious Web Crawler (Flask + BS4 + Qiskit)

A Python 3 / Flask web crawler that prioritizes its frontier with a
**Qiskit quantum decision pipeline** and manages exploration with
computational analogues of three current theories of consciousness:
**Orch-OR** (Penrose–Hameroff), **Integrated Information Theory (IIT)**
and **Global Workspace Theory (GWT)**.

Concepts extend
[stingraze/quantum-qiskit-decision-web-crawler](https://github.com/stingraze/quantum-qiskit-decision-web-crawler):
the 4×4 complex feature state, the CohesiveDiagonalMatrix4D transform,
the 5-qubit goodness circuit, hybrid quantum/heuristic/exploration
scoring and dead-end backtracking.

> The consciousness theories are used as **engineering metaphors /
> computational analogues** — this project makes no claim of machine
> sentience.

---

## How consciousness theory maps to frontier management

| Theory | Mechanism in the crawler |
| --- | --- |
| **Global Workspace Theory** (Baars, Dehaene) | Four specialist processors — the Qiskit circuit, a deterministic heuristic scorer, an exploration signal and a learned URL-value predictor — score every candidate in parallel. The `GlobalWorkspace` fuses their reports with adaptive **attention weights** and "broadcasts" one composite score (ignition). After each page fetch, specialists whose predictions matched the realized page value gain attention (workspace plasticity). |
| **Integrated Information Theory** (Tononi, IIT 4.0) | A **Φ proxy** is computed from the entanglement entropy between the goodness qubit and the feature register of the final statevector, plus mean bipartite entanglement across cuts. High-Φ (irreducibly integrated) decisions are treated as high-confidence and keep their contrast; low-Φ decisions are flattened toward 0.5 so exploration can compete. |
| **Orch-OR** (Penrose–Hameroff) | Every frontier candidate is a **superposed branch** accumulating gravitational self-energy `E_G ∝ composite × (0.5 + Φ)` per scheduler tick. A branch undergoes **objective reduction** — is selected for crawling — when its accumulated action reaches `ħ_sim` (Penrose criterion `τ = ħ / E_G`). Strong, integrated branches collapse in one tick; weak branches only win after long coherent survival. Each reduction is a discrete "conscious moment" that commits the crawler to a URL. |

## Decision pipeline (per candidate link)

1. **Feature state** — URL structure, anchor text, keyword hits,
   same-host flag, depth penalty, parent title and a hashed exploration
   signal populate a normalized 4×4 complex matrix (hashed sinusoid
   imaginary part).
2. **CohesiveDiagonalMatrix4D** — a structured complex transform that
   normalizes the state and tracks/adapts a coherence metric.
3. **Qiskit goodness circuit** — `θ[0..3]` from row-wise mean
   magnitudes, `φ[0..3]` from row-wise mean phases, bound into a
   5-qubit circuit (4 feature qubits + 1 goodness qubit) with `RY`/`RZ`
   rotations, a `CX` entangling chain and controlled interactions into
   the goodness qubit. The quantum score is `p_good = P(goodness = 1)`,
   evaluated shot-based with **Aer SamplerV2** or exactly via
   **Statevector** fallback.
4. **Φ measurement** — entanglement structure of the same statevector.
5. **Global Workspace broadcast** — composite score with Φ confidence
   gating.
6. **Orch-OR scheduling** — objective reduction selects the next URL.
7. **Prediction & learning** — after fetching, the realized page value
   (keyword density + content richness + link fanout) trains an online
   logistic ranker (frontier value prediction, concept from crawler v6)
   and reinforces workspace attention.

Dead-end backtracking: pages that enqueue ≤ `dead_end_threshold` new
links count as dead ends; after 3 dead ends on one host, branches on
other hosts receive a composite boost (branch diversification).

## Install & run

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py            # Flask UI at http://localhost:5000
```

Headless CLI run (no Flask):

```bash
python run_cli.py --seeds seeds.txt --max-pages 15 --max-depth 2
```

## Flask routes / JSON API

| Route | Description |
| --- | --- |
| `GET /` | Dashboard: launch crawls, list jobs |
| `POST /crawl` | Start a crawl from the HTML form |
| `GET /jobs/<id>` | Live job page (Φ, attention bars, frontier, results) |
| `POST /api/crawl` | Start a crawl: `{"seeds": ["https://…"], "max_pages": 20, "max_depth": 3, "shots": 128, "exploration_temperature": 0.35, "coherence_window": 12}` |
| `GET /api/jobs` | List jobs |
| `GET /api/jobs/<id>` | Status, events, metrics timeline, reduction log |
| `GET /api/jobs/<id>/results` | Crawl records |
| `GET /api/jobs/<id>/frontier` | Live superposed-branch snapshot |
| `POST /api/jobs/<id>/stop` | Graceful stop ("decoherence") |

## Project layout

```
app.py                     Flask app (UI + JSON API)
run_cli.py                 Headless runner
qcrawler/
  features.py              4×4 complex feature state + heuristics + transform
  quantum_engine.py        5-qubit Qiskit circuit, Φ proxy, OR collapse time
  consciousness.py         GlobalWorkspace + OrchORScheduler
  predictor.py             Online logistic URL-value predictor
  frontier.py              ConsciousFrontier (superposed branches, backtracking)
  crawler.py               BS4 fetch/parse loop + learning
  jobs.py                  Threaded job manager
templates/, static/        Dashboard UI
seeds.txt                  Default seed URLs
```

## Requirements

Python ≥ 3.10 · Flask · beautifulsoup4 · requests · numpy · qiskit
(qiskit-aer optional — statevector fallback is used when unavailable).

## Ethics & crawling etiquette

Configurable politeness delay, HTML-only fetching, per-page link caps
and a bounded frontier. Respect robots.txt and site terms for any
serious deployment.

## License / credits

MIT-style, for research and experimentation.
Original quantum decision crawler concept: Tsubasa Kato / Inspire Search Corp.
Qiskit is a registered trademark of IBM; this project is independent and
not affiliated with or endorsed by IBM.
