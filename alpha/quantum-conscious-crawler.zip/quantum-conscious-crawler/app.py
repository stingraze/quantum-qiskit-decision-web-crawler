#!/usr/bin/env python3
"""Flask front-end for the Quantum-Conscious Web Crawler.

Routes
------
GET  /                       dashboard (start crawls, list jobs)
POST /crawl                  start a crawl from the HTML form
GET  /jobs/<job_id>          live job page (auto-refreshing)

JSON API
--------
POST /api/crawl              {"seeds": [...], "max_pages": 20, ...}
GET  /api/jobs               list all jobs
GET  /api/jobs/<id>          job status + metrics timeline
GET  /api/jobs/<id>/results  crawl records
GET  /api/jobs/<id>/frontier live frontier snapshot (superposed branches)
POST /api/jobs/<id>/stop     request stop (graceful decoherence)
"""

from __future__ import annotations

from flask import Flask, abort, jsonify, redirect, render_template, request, url_for

from qcrawler import JobManager

app = Flask(__name__)
manager = JobManager()

DEFAULTS = {
    "max_pages": 20,
    "max_depth": 3,
    "shots": 128,
    "exploration_temperature": 0.35,
    "coherence_window": 12,
    "politeness_delay": 0.5,
}


def _parse_params(data: dict) -> dict:
    seeds_raw = data.get("seeds", "")
    if isinstance(seeds_raw, str):
        seeds = [s.strip() for s in seeds_raw.replace(",", "\n").splitlines() if s.strip()]
    else:
        seeds = [str(s).strip() for s in seeds_raw if str(s).strip()]
    if not seeds:
        abort(400, description="At least one seed URL is required.")

    params = {"seeds": seeds}
    for key, default in DEFAULTS.items():
        try:
            value = data.get(key, default)
            params[key] = type(default)(value) if value not in (None, "") else default
        except (TypeError, ValueError):
            params[key] = default
    params["max_pages"] = max(1, min(params["max_pages"], 200))
    params["max_depth"] = max(0, min(params["max_depth"], 8))
    params["shots"] = max(16, min(params["shots"], 4096))

    weights = {}
    for name in ("quantum", "heuristic", "exploration", "predictor"):
        try:
            w = float(data.get(f"weight_{name}", "") or 0.0)
            if w > 0:
                weights[name] = w
        except (TypeError, ValueError):
            pass
    if weights:
        params["workspace_weights"] = weights
    return params


# ---------------------------------------------------------------------------
# HTML pages
# ---------------------------------------------------------------------------

@app.route("/")
def dashboard():
    return render_template("dashboard.html", jobs=manager.list_jobs(),
                           defaults=DEFAULTS)


@app.route("/crawl", methods=["POST"])
def crawl_form():
    params = _parse_params(request.form.to_dict())
    job_id = manager.start_job(params)
    return redirect(url_for("job_page", job_id=job_id))


@app.route("/jobs/<job_id>")
def job_page(job_id: str):
    job = manager.get(job_id)
    if not job:
        abort(404)
    return render_template("job.html", job=manager.summary(job), job_id=job_id)


# ---------------------------------------------------------------------------
# JSON API
# ---------------------------------------------------------------------------

@app.route("/api/crawl", methods=["POST"])
def api_crawl():
    params = _parse_params(request.get_json(force=True, silent=True) or {})
    job_id = manager.start_job(params)
    return jsonify({"job_id": job_id, "params": params}), 202


@app.route("/api/jobs")
def api_jobs():
    return jsonify(manager.list_jobs())


@app.route("/api/jobs/<job_id>")
def api_job(job_id: str):
    job = manager.get(job_id)
    if not job:
        abort(404)
    crawler = job.get("crawler")
    payload = manager.summary(job)
    payload["events"] = job["events"][-50:]
    payload["metrics_timeline"] = crawler.metrics_timeline if crawler else []
    payload["reduction_log"] = (
        crawler.frontier.scheduler.reduction_log[-30:] if crawler else [])
    if job["result"] is not None:
        payload["result_summary"] = {
            k: v for k, v in job["result"].items()
            if k in ("pages_crawled", "duration_sec", "final_attention",
                     "quantum_backend", "backtrack_events")}
    return jsonify(payload)


@app.route("/api/jobs/<job_id>/results")
def api_job_results(job_id: str):
    job = manager.get(job_id)
    if not job:
        abort(404)
    crawler = job.get("crawler")
    return jsonify({"status": job["status"],
                    "results": crawler.results if crawler else []})


@app.route("/api/jobs/<job_id>/frontier")
def api_job_frontier(job_id: str):
    job = manager.get(job_id)
    if not job:
        abort(404)
    crawler = job.get("crawler")
    return jsonify({"status": job["status"],
                    "frontier": crawler.frontier.snapshot(limit=50) if crawler else []})


@app.route("/api/jobs/<job_id>/stop", methods=["POST"])
def api_job_stop(job_id: str):
    if not manager.stop(job_id):
        abort(404)
    return jsonify({"job_id": job_id, "stopping": True})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
