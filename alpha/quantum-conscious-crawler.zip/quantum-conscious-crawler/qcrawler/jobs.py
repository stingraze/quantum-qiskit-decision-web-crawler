"""Thread-based crawl job manager for the Flask app."""

from __future__ import annotations

import threading
import time
import traceback
import uuid
from typing import Dict, List, Optional

from .crawler import QuantumConsciousCrawler


class JobManager:
    def __init__(self, max_events: int = 500):
        self._jobs: Dict[str, Dict] = {}
        self._lock = threading.Lock()
        self.max_events = int(max_events)

    def start_job(self, params: Dict) -> str:
        job_id = uuid.uuid4().hex[:12]
        stop_flag = threading.Event()
        job = {
            "id": job_id,
            "status": "running",
            "params": params,
            "events": [],
            "result": None,
            "error": None,
            "started_at": time.time(),
            "finished_at": None,
            "stop_flag": stop_flag,
            "crawler": None,
        }
        with self._lock:
            self._jobs[job_id] = job

        def on_event(event: Dict) -> None:
            with self._lock:
                job["events"].append(event)
                if len(job["events"]) > self.max_events:
                    job["events"] = job["events"][-self.max_events:]

        def worker() -> None:
            try:
                crawler = QuantumConsciousCrawler(
                    seeds=params["seeds"],
                    max_pages=params.get("max_pages", 20),
                    max_depth=params.get("max_depth", 3),
                    shots=params.get("shots", 128),
                    exploration_temperature=params.get("exploration_temperature", 0.35),
                    coherence_window=params.get("coherence_window", 12),
                    politeness_delay=params.get("politeness_delay", 0.5),
                    workspace_weights=params.get("workspace_weights"),
                    on_event=on_event,
                    stop_flag=stop_flag,
                )
                job["crawler"] = crawler
                result = crawler.run()
                with self._lock:
                    job["result"] = result
                    job["status"] = "stopped" if stop_flag.is_set() else "completed"
            except Exception as exc:  # pragma: no cover
                with self._lock:
                    job["status"] = "failed"
                    job["error"] = f"{exc}\n{traceback.format_exc()}"
            finally:
                job["finished_at"] = time.time()

        threading.Thread(target=worker, daemon=True).start()
        return job_id

    def get(self, job_id: str) -> Optional[Dict]:
        with self._lock:
            return self._jobs.get(job_id)

    def stop(self, job_id: str) -> bool:
        job = self.get(job_id)
        if not job:
            return False
        job["stop_flag"].set()
        return True

    def list_jobs(self) -> List[Dict]:
        with self._lock:
            return [self.summary(j) for j in self._jobs.values()]

    @staticmethod
    def summary(job: Dict) -> Dict:
        crawler = job.get("crawler")
        return {
            "id": job["id"],
            "status": job["status"],
            "seeds": job["params"].get("seeds", []),
            "max_pages": job["params"].get("max_pages"),
            "pages_crawled": len(crawler.results) if crawler else 0,
            "frontier_size": len(crawler.frontier) if crawler else 0,
            "attention": crawler.workspace.snapshot() if crawler else {},
            "started_at": job["started_at"],
            "finished_at": job["finished_at"],
            "error": job["error"],
        }
