"""Quantum-conscious web crawler package.

BS4 + Qiskit crawler with consciousness-theory-inspired frontier
management: Global Workspace fusion, IIT Phi confidence gating and
Orch-OR objective-reduction scheduling.

Concepts extend https://github.com/stingraze/quantum-qiskit-decision-web-crawler
"""

from .crawler import QuantumConsciousCrawler
from .jobs import JobManager

__all__ = ["QuantumConsciousCrawler", "JobManager"]
__version__ = "1.0.0"
