"""Lightweight online logistic ranker (prediction specialist).

Concept from quantum-decision-crawler6.py: a tiny model learns to
predict the realized value of pages so the frontier can rank unvisited
branches.  Pure NumPy so it runs anywhere.
"""

from __future__ import annotations

from typing import List
from urllib.parse import urlparse

import numpy as np

from .features import LinkCandidate, keyword_hits


def candidate_features(cand: LinkCandidate) -> np.ndarray:
    p = urlparse(cand.url)
    same_host = 1.0 if cand.host == urlparse(cand.parent_url).netloc.lower() else 0.0
    return np.array([
        same_host,
        min(1.0, len([s for s in p.path.split("/") if s]) / 6.0),   # path depth
        min(1.0, keyword_hits(cand.anchor_text) / 3.0),
        min(1.0, keyword_hits(p.path) / 3.0),
        min(1.0, len(cand.parent_title) / 80.0),
        min(1.0, cand.depth / 6.0),
    ], dtype=np.float32)


class OnlineURLValuePredictor:
    """Logistic regression trained online from realized page values."""

    def __init__(self, lr: float = 0.08, replay_size: int = 400, epochs: int = 4):
        self.lr = float(lr)
        self.epochs = int(epochs)
        self.replay_size = int(replay_size)
        self.w = np.zeros(6, dtype=np.float32)
        self.b = 0.0
        self._X: List[np.ndarray] = []
        self._y: List[float] = []
        self.samples_seen = 0

    @staticmethod
    def _sigmoid(z):
        return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))

    def observe(self, cand: LinkCandidate, realized_value: float) -> None:
        """Record (features, realized value) and take a few SGD steps."""
        self._X.append(candidate_features(cand))
        self._y.append(float(np.clip(realized_value, 0.0, 1.0)))
        if len(self._X) > self.replay_size:
            self._X.pop(0)
            self._y.pop(0)
        self.samples_seen += 1
        X = np.stack(self._X)
        y = np.asarray(self._y, dtype=np.float32)
        for _ in range(self.epochs):
            p = self._sigmoid(X @ self.w + self.b)
            self.w -= self.lr * (X.T @ (p - y)) / len(X)
            self.b -= self.lr * float(np.mean(p - y))

    def predict(self, cand: LinkCandidate) -> float:
        if self.samples_seen < 5:
            return 0.5  # uninformed prior until the model has warmed up
        x = candidate_features(cand)
        return float(self._sigmoid(x @ self.w + self.b))
