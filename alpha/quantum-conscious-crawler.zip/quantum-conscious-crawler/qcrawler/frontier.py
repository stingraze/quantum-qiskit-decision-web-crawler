"""Conscious frontier manager.

Holds superposed candidate branches, delegates selection to the
Orch-OR scheduler and implements dead-end detection with backtracking
boost (concept from quantum-decision-crawler4.py).
"""

from __future__ import annotations

from typing import Dict, List, Optional
from urllib.parse import urlparse

from .consciousness import OrchORScheduler, SuperposedBranch
from .features import LinkCandidate


class ConsciousFrontier:
    def __init__(self, coherence_window: int = 12,
                 dead_end_threshold: int = 1,
                 dead_ends_before_boost: int = 3,
                 backtrack_boost: float = 0.15,
                 max_size: int = 2000):
        self.scheduler = OrchORScheduler(coherence_window=coherence_window)
        self.branches: Dict[str, SuperposedBranch] = {}
        self.dead_end_threshold = int(dead_end_threshold)
        self.dead_ends_before_boost = int(dead_ends_before_boost)
        self.backtrack_boost = float(backtrack_boost)
        self.max_size = int(max_size)
        self._dead_ends_per_host: Dict[str, int] = {}
        self.backtrack_events: List[Dict] = []

    def __len__(self) -> int:
        return len(self.branches)

    def add(self, cand: LinkCandidate) -> bool:
        if cand.url in self.branches:
            # Keep the better-scored version of a rediscovered link.
            if cand.composite > self.branches[cand.url].candidate.composite:
                self.branches[cand.url].candidate = cand
            return False
        if len(self.branches) >= self.max_size:
            self._evict_weakest()
        self.branches[cand.url] = SuperposedBranch(candidate=cand)
        return True

    def _evict_weakest(self) -> None:
        weakest = min(self.branches.values(), key=lambda b: b.candidate.composite)
        self.branches.pop(weakest.candidate.url, None)

    def pop_next(self) -> Optional[LinkCandidate]:
        branch = self.scheduler.select(list(self.branches.values()))
        if branch is None:
            return None
        self.branches.pop(branch.candidate.url, None)
        return branch.candidate

    # ------------------------------------------------------------------
    # Dead-end backtracking
    # ------------------------------------------------------------------
    def report_page_result(self, url: str, new_links_enqueued: int) -> None:
        """A page is a dead end when it enqueues <= threshold new links.
        After enough dead ends on one host, sibling branches on other
        hosts get a backtracking boost (branch diversification)."""
        host = urlparse(url).netloc.lower()
        if new_links_enqueued <= self.dead_end_threshold:
            self._dead_ends_per_host[host] = self._dead_ends_per_host.get(host, 0) + 1
            if self._dead_ends_per_host[host] >= self.dead_ends_before_boost:
                self._boost_other_hosts(host)
                self._dead_ends_per_host[host] = 0
        else:
            self._dead_ends_per_host[host] = 0

    def _boost_other_hosts(self, dead_host: str) -> None:
        boosted = 0
        for branch in self.branches.values():
            if branch.candidate.host != dead_host:
                branch.candidate.composite = min(
                    1.0, branch.candidate.composite + self.backtrack_boost)
                boosted += 1
        self.backtrack_events.append({"dead_host": dead_host, "boosted": boosted})

    def snapshot(self, limit: int = 25) -> List[Dict]:
        ordered = sorted(self.branches.values(),
                         key=lambda b: b.candidate.composite, reverse=True)
        return [{
            "url": b.candidate.url,
            "composite": round(b.candidate.composite, 4),
            "phi": round(b.candidate.phi, 4),
            "quantum": round(b.candidate.quantum_score, 4),
            "heuristic": round(b.candidate.heuristic_score, 4),
            "predictor": round(b.candidate.predicted_value, 4),
            "depth": b.candidate.depth,
            "accumulated_action": round(b.accumulated_action, 4),
        } for b in ordered[:limit]]
