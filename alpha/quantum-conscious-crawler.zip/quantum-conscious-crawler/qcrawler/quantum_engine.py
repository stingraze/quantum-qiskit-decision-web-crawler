"""Qiskit decision engine.

Implements the 5-qubit "goodness probability" model from
stingraze/quantum-qiskit-decision-web-crawler and extends it with two
consciousness-theory-inspired measurements:

* An IIT-style integrated-information proxy (Phi) computed from the
  entanglement entropy between the goodness qubit and the feature
  register of the final statevector.
* An Orch-OR-style objective-reduction time tau = hbar_sim / E_G where
  the "gravitational self-energy" analogue E_G grows with the coherent
  superposition mass of the decision state.  Candidates whose decision
  state carries more integrated information collapse (are selected)
  sooner - Penrose-Hameroff reduction as a frontier scheduler.
"""

from __future__ import annotations

import math
from typing import Tuple

import numpy as np
from qiskit import QuantumCircuit
from qiskit.quantum_info import Statevector, partial_trace, entropy

try:  # Shot-based sampling when Aer is available.
    from qiskit_aer.primitives import SamplerV2 as AerSampler
    AER_AVAILABLE = True
except Exception:  # pragma: no cover - statevector fallback always works.
    AerSampler = None
    AER_AVAILABLE = False

HBAR_SIM = 1.0  # simulation-scale Planck constant for OR timing


class QuantumDecisionEngine:
    """Reduces a transformed 4x4 complex state to circuit parameters and
    evaluates the goodness qubit."""

    def __init__(self, shots: int = 256, use_aer: bool = True):
        self.shots = int(shots)
        self.use_aer = bool(use_aer) and AER_AVAILABLE
        self._sampler = AerSampler() if self.use_aer else None

    # ------------------------------------------------------------------
    # Parameterization
    # ------------------------------------------------------------------
    @staticmethod
    def parameters_from_state(state: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """theta from row-wise mean magnitudes, phi from row-wise mean phases."""
        mags = np.abs(state).mean(axis=1)
        phases = np.angle(state).mean(axis=1)
        theta = np.pi * mags / (mags.max() + 1e-12)
        phi = phases  # already in [-pi, pi]
        return theta, phi

    # ------------------------------------------------------------------
    # Circuit
    # ------------------------------------------------------------------
    @staticmethod
    def build_circuit(theta: np.ndarray, phi: np.ndarray, measured: bool = False) -> QuantumCircuit:
        """4 feature qubits + 1 goodness qubit (index 4)."""
        qc = QuantumCircuit(5, 1 if measured else 0)
        for q in range(4):
            qc.ry(float(theta[q]), q)
            qc.rz(float(phi[q]), q)
        # Entangling CX chain over feature qubits.
        for q in range(3):
            qc.cx(q, q + 1)
        # Controlled interactions into the goodness qubit.
        for q in range(4):
            qc.cry(float(theta[q]) / 2.0, q, 4)
        qc.cx(3, 4)
        qc.cry(float(np.mean(phi)) / 2.0 + math.pi / 8.0, 0, 4)
        if measured:
            qc.measure(4, 0)
        return qc

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------
    def evaluate(self, state: np.ndarray) -> dict:
        """Return p_good, phi (integration proxy) and OR collapse time."""
        theta, phi_params = self.parameters_from_state(state)

        # Exact statevector pass (always available; also used for Phi).
        sv_circuit = self.build_circuit(theta, phi_params, measured=False)
        sv = Statevector.from_instruction(sv_circuit)

        p_good = self._p_good(sv, theta, phi_params)
        phi_integration = self._integrated_information(sv)
        collapse_time, e_g = self._orch_or_collapse_time(sv, phi_integration)

        return {
            "p_good": float(p_good),
            "phi": float(phi_integration),
            "collapse_time": float(collapse_time),
            "self_energy": float(e_g),
            "backend": "aer-sampler" if self.use_aer else "statevector",
        }

    def _p_good(self, sv: Statevector, theta: np.ndarray, phi_params: np.ndarray) -> float:
        """P(goodness qubit == 1), shot-based when Aer is available."""
        if self.use_aer and self._sampler is not None:
            try:
                qc = self.build_circuit(theta, phi_params, measured=True)
                job = self._sampler.run([qc], shots=self.shots)
                counts = job.result()[0].data.c.get_counts()
                total = sum(counts.values()) or 1
                return counts.get("1", 0) / total
            except Exception:
                pass  # fall through to exact probability
        probs = sv.probabilities([4])
        return float(probs[1])

    @staticmethod
    def _integrated_information(sv: Statevector) -> float:
        """IIT-inspired Phi proxy in [0, 1].

        True IIT Phi is intractable; we use the entanglement entropy of the
        goodness qubit with the feature register plus the mean bipartite
        entanglement across feature cuts - a measure of how irreducibly the
        decision state integrates its parts (Tononi's integration axiom).
        """
        rho_good = partial_trace(sv, [0, 1, 2, 3])       # goodness qubit
        s_good = entropy(rho_good, base=2)               # in [0, 1]
        cut_entropies = []
        for cut in ([0], [0, 1], [0, 1, 2]):
            keep = [q for q in range(5) if q not in cut]
            rho = partial_trace(sv, keep)
            n = len(cut)
            cut_entropies.append(entropy(rho, base=2) / n)
        s_cuts = float(np.mean(cut_entropies))
        return float(np.clip(0.6 * s_good + 0.4 * s_cuts, 0.0, 1.0))

    @staticmethod
    def _orch_or_collapse_time(sv: Statevector, phi_integration: float) -> Tuple[float, float]:
        """Orch-OR objective reduction: tau = hbar / E_G.

        E_G (gravitational self-energy of the superposition separation) is
        modelled as the superposition "mass": participation of basis states
        in the final decision state, weighted by integration Phi.  Larger,
        more integrated superpositions self-collapse faster - they reach
        the Penrose threshold sooner and win the frontier race.
        """
        amplitudes = np.abs(sv.data) ** 2
        participation = 1.0 / float(np.sum(amplitudes ** 2))  # effective # of branches
        superposition_mass = (participation - 1.0) / (len(amplitudes) - 1.0)
        e_g = max(1e-6, superposition_mass * (0.5 + phi_integration))
        tau = HBAR_SIM / e_g
        return tau, e_g
