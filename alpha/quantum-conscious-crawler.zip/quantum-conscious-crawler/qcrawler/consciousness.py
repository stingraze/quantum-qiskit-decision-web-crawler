"""Consciousness-theory layer for frontier management.

Three current theories of consciousness are mapped onto the crawler:

1. Global Workspace Theory (Baars/Dehaene).  Multiple specialist
   processors (quantum circuit, deterministic heuristics, exploration,
   learned predictor) score every candidate in parallel.  The workspace
   fuses their reports with adaptive attention weights and "broadcasts"
   a single composite value - the ignition step that makes one candidate
   globally available for action.

2. Integrated Information Theory (Tononi, IIT 4.0).  A Phi proxy from
   the entanglement structure of the Qiskit decision state measures how
   irreducibly integrated a decision is.  High-Phi decisions are treated
   as high-confidence and sharpen the composite score; low-Phi decisions
   are treated as noisy and are flattened toward exploration.

3. Orch-OR (Penrose-Hameroff orchestrated objective reduction).  Every
   frontier candidate is held as a superposed possibility that
   accumulates gravitational self-energy E_G over scheduler ticks.  When
   the accumulated E_G x t reaches hbar_sim the branch undergoes
   objective reduction - a discrete "moment of experience" that commits
   the crawler to that URL.  Candidates with more integrated, more
   massive superpositions collapse sooner (tau = hbar / E_G).

The theories are used as engineering metaphors: the implementation is a
faithful computational analogue, not a claim about machine sentience.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np

from .features import LinkCandidate
from .quantum_engine import HBAR_SIM

SPECIALISTS = ("quantum", "heuristic", "exploration", "predictor")


@dataclass
class WorkspaceEvent:
    """One broadcast (ignition) recorded by the global workspace."""

    url: str
    composite: float
    phi: float
    winning_specialist: str
    attention: Dict[str, float]
    timestamp: float = field(default_factory=time.time)


class GlobalWorkspace:
    """Fuses specialist scores with adaptive attention weights."""

    def __init__(self, initial_weights: Optional[Dict[str, float]] = None,
                 learning_rate: float = 0.06):
        w = initial_weights or {"quantum": 0.4, "heuristic": 0.3,
                                "exploration": 0.15, "predictor": 0.15}
        self.attention = {k: float(w.get(k, 0.0)) for k in SPECIALISTS}
        self._normalize()
        self.learning_rate = float(learning_rate)
        self.broadcasts: List[WorkspaceEvent] = []

    def _normalize(self) -> None:
        total = sum(self.attention.values()) or 1.0
        for k in self.attention:
            self.attention[k] = max(0.02, self.attention[k] / total)
        total = sum(self.attention.values())
        for k in self.attention:
            self.attention[k] /= total

    def broadcast(self, cand: LinkCandidate) -> float:
        """Ignition: fuse specialist reports into one composite score.

        Phi acts as a confidence gate (IIT): integrated decisions keep
        their contrast, poorly integrated ones are flattened so that
        exploration can compete.
        """
        scores = {
            "quantum": cand.quantum_score,
            "heuristic": cand.heuristic_score,
            "exploration": cand.exploration_score,
            "predictor": cand.predicted_value,
        }
        cand.specialist_scores = scores
        fused = sum(self.attention[k] * scores[k] for k in SPECIALISTS)
        confidence = 0.5 + 0.5 * cand.phi          # in [0.5, 1]
        composite = confidence * fused + (1.0 - confidence) * 0.5
        cand.composite = float(np.clip(composite, 0.0, 1.0))

        winner = max(scores, key=lambda k: self.attention[k] * scores[k])
        self.broadcasts.append(WorkspaceEvent(
            url=cand.url, composite=cand.composite, phi=cand.phi,
            winning_specialist=winner, attention=dict(self.attention)))
        return cand.composite

    def reinforce(self, cand: LinkCandidate, realized_value: float) -> None:
        """Credit assignment: specialists whose prediction matched the
        realized page value gain attention (workspace plasticity)."""
        if not cand.specialist_scores:
            return
        for k in SPECIALISTS:
            err = abs(cand.specialist_scores.get(k, 0.5) - realized_value)
            self.attention[k] += self.learning_rate * (0.5 - err)
        self._normalize()

    def snapshot(self) -> Dict[str, float]:
        return dict(self.attention)


@dataclass
class SuperposedBranch:
    """A frontier candidate held in superposition awaiting reduction."""

    candidate: LinkCandidate
    accumulated_action: float = 0.0   # integral of E_G dt

    def tick(self, dt: float = 1.0) -> None:
        e_g = max(1e-6, self.candidate.composite * (0.5 + self.candidate.phi))
        self.accumulated_action += e_g * dt

    @property
    def reduced(self) -> bool:
        """Penrose criterion: reduction when accumulated E_G x t >= hbar."""
        return self.accumulated_action >= HBAR_SIM


class OrchORScheduler:
    """Selects the next URL via simulated objective reduction.

    Instead of always popping the maximum-priority item, every branch in
    the (bounded) coherence window accumulates self-energy each tick and
    the first branch to reach the Penrose threshold is reduced/selected.
    This yields best-first behaviour with principled, Phi-weighted
    stochasticity: strong branches collapse in one tick, weak branches
    only win after long coherent survival - a discrete stream of
    "conscious moments" driving the crawl.
    """

    def __init__(self, coherence_window: int = 12, max_ticks: int = 50):
        self.coherence_window = int(coherence_window)
        self.max_ticks = int(max_ticks)
        self.reduction_log: List[Dict] = []

    def select(self, branches: List[SuperposedBranch]) -> Optional[SuperposedBranch]:
        if not branches:
            return None
        window = sorted(branches, key=lambda b: b.candidate.composite,
                        reverse=True)[: self.coherence_window]
        chosen: Optional[SuperposedBranch] = None
        ticks = 0
        while chosen is None and ticks < self.max_ticks:
            ticks += 1
            for branch in window:
                branch.tick(dt=1.0)
                if branch.reduced:
                    chosen = branch
                    break
        if chosen is None:  # decoherence fallback: classical argmax
            chosen = window[0]
        self.reduction_log.append({
            "url": chosen.candidate.url,
            "ticks": ticks,
            "phi": chosen.candidate.phi,
            "composite": chosen.candidate.composite,
            "collapse_time_model": chosen.candidate.collapse_time,
        })
        return chosen
