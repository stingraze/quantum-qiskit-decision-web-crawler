"""Feature-state construction for candidate outlinks.

Follows the concept from stingraze/quantum-qiskit-decision-web-crawler:
each candidate link is encoded as a normalized 4x4 complex-valued
"feature state" built from URL structure, anchor context, relationship
to the parent page and an exploration signal.  A hashed sinusoid adds
an imaginary component so the state behaves like a quantum-style input.
"""

from __future__ import annotations

import hashlib
import math
import random
from dataclasses import dataclass, field
from typing import List
from urllib.parse import urlparse

import numpy as np

HIGH_VALUE_KEYWORDS = [
    "research", "paper", "whitepaper", "publication", "docs", "api",
    "reference", "spec", "guide", "tutorial", "handbook", "about",
    "company", "team", "learn", "article", "blog", "news", "resources",
    "developers", "community", "overview", "features", "solutions",
    "quantum", "science", "technology",
]

LOW_VALUE_TOKENS = [
    "signout", "logout", "login", "signin", "cart", "checkout",
    "privacy-policy", "terms-of-service", "cookie-policy", "share",
    "unsubscribe", "tracking",
]


@dataclass
class LinkCandidate:
    """A candidate outlink waiting in the frontier."""

    url: str
    anchor_text: str = ""
    parent_url: str = ""
    parent_title: str = ""
    depth: int = 0
    # Filled in by the scoring pipeline:
    quantum_score: float = 0.0
    heuristic_score: float = 0.0
    exploration_score: float = 0.0
    predicted_value: float = 0.0
    phi: float = 0.0                # IIT-style integrated-information proxy
    collapse_time: float = 1e9     # Orch-OR objective-reduction time (sim units)
    composite: float = 0.0
    specialist_scores: dict = field(default_factory=dict)

    @property
    def host(self) -> str:
        return urlparse(self.url).netloc.lower()


def _hash_unit(text: str, salt: str = "") -> float:
    """Deterministic pseudo-random value in [0, 1) derived from a hash."""
    digest = hashlib.sha256((salt + text).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") / float(1 << 64)


def keyword_hits(text: str) -> int:
    low = text.lower()
    return sum(1 for kw in HIGH_VALUE_KEYWORDS if kw in low)


def low_value_penalty(url: str) -> float:
    low = url.lower()
    return 0.25 if any(tok in low for tok in LOW_VALUE_TOKENS) else 1.0


def heuristic_score(cand: LinkCandidate) -> float:
    """Deterministic heuristic scorer (same-host, brevity, keywords, depth)."""
    p = urlparse(cand.url)
    same_host = 1.0 if cand.host and cand.host == urlparse(cand.parent_url).netloc.lower() else 0.0
    brevity = max(0.0, 1.0 - len(cand.url) / 160.0)
    anchor_kw = min(1.0, keyword_hits(cand.anchor_text) / 3.0)
    path_kw = min(1.0, keyword_hits(p.path) / 3.0)
    depth_pen = max(0.0, 1.0 - 0.12 * cand.depth)
    title_sig = min(1.0, len(cand.parent_title) / 80.0)
    raw = (0.28 * same_host + 0.16 * brevity + 0.22 * anchor_kw
           + 0.18 * path_kw + 0.10 * depth_pen + 0.06 * title_sig)
    return float(np.clip(raw * low_value_penalty(cand.url), 0.0, 1.0))


def exploration_score(cand: LinkCandidate, temperature: float = 0.35) -> float:
    """Blend of hash-derived pseudo-deterministic signal and true randomness."""
    deterministic = _hash_unit(cand.url, salt="explore")
    noise = random.random()
    t = float(np.clip(temperature, 0.0, 1.0))
    return float((1.0 - t) * deterministic + t * noise)


def build_feature_state(cand: LinkCandidate) -> np.ndarray:
    """Build the normalized 4x4 complex feature state for one candidate."""
    p = urlparse(cand.url)
    url_len = min(1.0, len(cand.url) / 160.0)
    path_len = min(1.0, len(p.path) / 80.0)
    anchor_len = min(1.0, len(cand.anchor_text) / 60.0)
    kw = min(1.0, keyword_hits(cand.anchor_text + " " + p.path) / 4.0)
    same_host = 1.0 if cand.host == urlparse(cand.parent_url).netloc.lower() else 0.0
    depth_pen = max(0.0, 1.0 - 0.15 * cand.depth)
    title_sig = min(1.0, len(cand.parent_title) / 80.0)
    explore = _hash_unit(cand.url, salt="state")

    real = np.array([
        [url_len,   path_len,  anchor_len, kw],
        [same_host, depth_pen, title_sig,  explore],
        [kw,        same_host, url_len,    depth_pen],
        [explore,   anchor_len, path_len,  title_sig],
    ], dtype=np.float64)

    # Hashed sinusoid imaginary component -> complex quantum-style state.
    base = _hash_unit(cand.url, salt="phase") * 2.0 * math.pi
    rows, cols = np.meshgrid(np.arange(4), np.arange(4), indexing="ij")
    imag = 0.25 * np.sin(base + 0.9 * rows + 1.7 * cols)

    state = real + 1j * imag
    norm = np.linalg.norm(state)
    if norm > 1e-12:
        state = state / norm
    return state


class CohesiveDiagonalMatrix4D:
    """Structured complex transform applied to the feature state.

    Contracts a fixed 4D diagonal tensor with the 4x4 input state,
    normalizes the output and tracks a running coherence metric that can
    adapt the tensor over time (concept from the original repository).
    """

    def __init__(self, adapt_rate: float = 0.02):
        idx = np.arange(4, dtype=np.float64)
        self.diag = np.exp(1j * (0.5 * np.pi * idx / 4.0)) * (0.7 + 0.3 * (idx + 1) / 4.0)
        self.adapt_rate = adapt_rate
        self.coherence_history: List[float] = []

    def transform(self, state: np.ndarray) -> np.ndarray:
        out = (self.diag[:, None] * state) * self.diag[None, :].conj()
        norm = np.linalg.norm(out)
        if norm > 1e-12:
            out = out / norm
        fidelity = float(np.abs(np.vdot(state.ravel(), out.ravel())) ** 2)
        self.coherence_history.append(fidelity)
        # Slow adaptation: rotate the tensor phase toward higher fidelity.
        drift = self.adapt_rate * (fidelity - 0.5)
        self.diag = self.diag * np.exp(1j * drift)
        return out

    @property
    def mean_coherence(self) -> float:
        if not self.coherence_history:
            return 0.0
        return float(np.mean(self.coherence_history[-50:]))
