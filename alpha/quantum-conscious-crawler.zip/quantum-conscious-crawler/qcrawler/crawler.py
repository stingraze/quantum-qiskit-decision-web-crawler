"""Quantum-conscious web crawler orchestrator (Beautiful Soup 4)."""

from __future__ import annotations

import logging
import re
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import urldefrag, urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from .consciousness import GlobalWorkspace
from .features import (CohesiveDiagonalMatrix4D, LinkCandidate,
                       build_feature_state, exploration_score,
                       heuristic_score, keyword_hits)
from .frontier import ConsciousFrontier
from .predictor import OnlineURLValuePredictor
from .quantum_engine import QuantumDecisionEngine

logger = logging.getLogger("qcrawler")

SKIP_EXTENSIONS = re.compile(
    r"\.(png|jpe?g|gif|svg|webp|ico|pdf|zip|gz|tar|mp4|mp3|avi|css|js|woff2?)$", re.I)


def normalize_url(url: str) -> str:
    clean = urldefrag(url.strip())[0]
    p = urlparse(clean)
    scheme = (p.scheme or "https").lower()
    netloc = p.netloc.lower()
    path = p.path or "/"
    if len(path) > 1 and path.endswith("/"):
        path = path[:-1]
    return f"{scheme}://{netloc}{path}" + (f"?{p.query}" if p.query else "")


def allowed(url: str) -> bool:
    p = urlparse(url)
    if p.scheme not in ("http", "https"):
        return False
    return not SKIP_EXTENSIONS.search(p.path or "")


class QuantumConsciousCrawler:
    """Best-first crawler whose frontier is managed by objective reduction."""

    def __init__(self,
                 seeds: List[str],
                 max_pages: int = 20,
                 max_depth: int = 3,
                 shots: int = 128,
                 exploration_temperature: float = 0.35,
                 coherence_window: int = 12,
                 max_links_per_page: int = 40,
                 request_timeout: float = 8.0,
                 politeness_delay: float = 0.5,
                 workspace_weights: Optional[Dict[str, float]] = None,
                 on_event: Optional[Callable[[Dict], None]] = None,
                 stop_flag: Optional[threading.Event] = None):
        self.seeds = [normalize_url(s) for s in seeds if s.strip()]
        self.max_pages = int(max_pages)
        self.max_depth = int(max_depth)
        self.exploration_temperature = float(exploration_temperature)
        self.max_links_per_page = int(max_links_per_page)
        self.request_timeout = float(request_timeout)
        self.politeness_delay = float(politeness_delay)
        self.on_event = on_event or (lambda e: None)
        self.stop_flag = stop_flag or threading.Event()

        self.engine = QuantumDecisionEngine(shots=shots)
        self.transform = CohesiveDiagonalMatrix4D()
        self.workspace = GlobalWorkspace(initial_weights=workspace_weights)
        self.frontier = ConsciousFrontier(coherence_window=coherence_window)
        self.predictor = OnlineURLValuePredictor()

        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "QuantumConsciousCrawler/1.0 (+research; BS4+Qiskit)"})

        self.visited: set = set()
        self.results: List[Dict] = []
        self.metrics_timeline: List[Dict] = []

    # ------------------------------------------------------------------
    # Scoring pipeline
    # ------------------------------------------------------------------
    def score_candidate(self, cand: LinkCandidate) -> LinkCandidate:
        state = build_feature_state(cand)
        transformed = self.transform.transform(state)
        q = self.engine.evaluate(transformed)
        cand.quantum_score = q["p_good"]
        cand.phi = q["phi"]
        cand.collapse_time = q["collapse_time"]
        cand.heuristic_score = heuristic_score(cand)
        cand.exploration_score = exploration_score(cand, self.exploration_temperature)
        cand.predicted_value = self.predictor.predict(cand)
        self.workspace.broadcast(cand)
        return cand

    # ------------------------------------------------------------------
    # Fetch / parse
    # ------------------------------------------------------------------
    def fetch(self, url: str) -> Optional[str]:
        try:
            r = self.session.get(url, timeout=self.request_timeout)
            if r.status_code >= 400:
                return None
            if "text/html" not in (r.headers.get("Content-Type") or ""):
                return None
            return r.text
        except requests.RequestException:
            return None

    def parse(self, base_url: str, html: str) -> Tuple[str, str, List[Tuple[str, str]]]:
        soup = BeautifulSoup(html, "html.parser")
        title = (soup.title.string or "").strip() if soup.title and soup.title.string else ""
        text = soup.get_text(" ", strip=True)[:4000]
        links: List[Tuple[str, str]] = []
        seen = set()
        for a in soup.find_all("a", href=True):
            href = normalize_url(urljoin(base_url, a["href"]))
            if href in seen or not allowed(href):
                continue
            seen.add(href)
            links.append((href, a.get_text(" ", strip=True)[:120]))
            if len(links) >= self.max_links_per_page:
                break
        return title, text, links

    @staticmethod
    def realized_page_value(title: str, text: str, n_links: int) -> float:
        """Ground-truth signal used to train the predictor and reinforce
        workspace attention: content richness + keyword density + fanout."""
        kw = min(1.0, keyword_hits(title + " " + text[:1500]) / 6.0)
        richness = min(1.0, len(text) / 3000.0)
        fanout = min(1.0, n_links / 25.0)
        return 0.45 * kw + 0.35 * richness + 0.20 * fanout

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------
    def run(self) -> Dict:
        started = time.time()
        for seed in self.seeds:
            cand = LinkCandidate(url=seed, anchor_text="seed", parent_url=seed,
                                 parent_title="", depth=0)
            self.score_candidate(cand)
            self.frontier.add(cand)

        while (len(self.results) < self.max_pages and len(self.frontier) > 0
               and not self.stop_flag.is_set()):
            cand = self.frontier.pop_next()
            if cand is None or cand.url in self.visited:
                continue
            self.visited.add(cand.url)

            html = self.fetch(cand.url)
            if html is None:
                self.frontier.report_page_result(cand.url, 0)
                self.on_event({"type": "fetch_failed", "url": cand.url})
                continue

            title, text, links = self.parse(cand.url, html)
            realized = self.realized_page_value(title, text, len(links))

            # Learning: predictor + workspace attention plasticity.
            self.predictor.observe(cand, realized)
            self.workspace.reinforce(cand, realized)

            enqueued = 0
            if cand.depth < self.max_depth:
                for href, anchor in links:
                    if href in self.visited or self.stop_flag.is_set():
                        continue
                    child = LinkCandidate(url=href, anchor_text=anchor,
                                          parent_url=cand.url, parent_title=title,
                                          depth=cand.depth + 1)
                    self.score_candidate(child)
                    if self.frontier.add(child):
                        enqueued += 1
            self.frontier.report_page_result(cand.url, enqueued)

            record = {
                "order": len(self.results) + 1,
                "url": cand.url,
                "title": title,
                "depth": cand.depth,
                "realized_value": round(realized, 4),
                "composite": round(cand.composite, 4),
                "quantum_score": round(cand.quantum_score, 4),
                "heuristic_score": round(cand.heuristic_score, 4),
                "predicted_value": round(cand.predicted_value, 4),
                "phi": round(cand.phi, 4),
                "collapse_time": round(cand.collapse_time, 4),
                "links_found": len(links),
                "links_enqueued": enqueued,
                "fetched_at": time.time(),
            }
            self.results.append(record)
            self.metrics_timeline.append({
                "page": len(self.results),
                "phi": round(cand.phi, 4),
                "composite": round(cand.composite, 4),
                "attention": self.workspace.snapshot(),
                "frontier_size": len(self.frontier),
                "mean_coherence": round(self.transform.mean_coherence, 4),
            })
            self.on_event({"type": "page", **record})
            time.sleep(self.politeness_delay)

        return {
            "pages_crawled": len(self.results),
            "duration_sec": round(time.time() - started, 2),
            "results": self.results,
            "metrics_timeline": self.metrics_timeline,
            "final_attention": self.workspace.snapshot(),
            "reduction_log": self.frontier.scheduler.reduction_log[-100:],
            "backtrack_events": self.frontier.backtrack_events,
            "frontier_remaining": self.frontier.snapshot(limit=25),
            "quantum_backend": "aer-sampler" if self.engine.use_aer else "statevector",
        }
