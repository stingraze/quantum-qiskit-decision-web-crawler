#!/usr/bin/env python3
"""Headless CLI runner for the quantum-conscious crawler."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

from qcrawler import QuantumConsciousCrawler


def main() -> int:
    ap = argparse.ArgumentParser(description="Quantum-conscious web crawler (CLI)")
    ap.add_argument("--seeds", default="seeds.txt",
                    help="Path to seeds file (one URL per line) or a single URL")
    ap.add_argument("--max-pages", type=int, default=15)
    ap.add_argument("--max-depth", type=int, default=2)
    ap.add_argument("--shots", type=int, default=128)
    ap.add_argument("--exploration-temperature", type=float, default=0.35)
    ap.add_argument("--coherence-window", type=int, default=12)
    ap.add_argument("--politeness-delay", type=float, default=0.5)
    ap.add_argument("--output", default="crawl_result.json")
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s")

    seeds_path = Path(args.seeds)
    if seeds_path.exists():
        seeds = [ln.strip() for ln in seeds_path.read_text().splitlines() if ln.strip()]
    else:
        seeds = [args.seeds]

    crawler = QuantumConsciousCrawler(
        seeds=seeds,
        max_pages=args.max_pages,
        max_depth=args.max_depth,
        shots=args.shots,
        exploration_temperature=args.exploration_temperature,
        coherence_window=args.coherence_window,
        politeness_delay=args.politeness_delay,
        on_event=lambda e: print(
            f"[{e['type']}] {e.get('url', '')} "
            f"composite={e.get('composite', '')} phi={e.get('phi', '')}"),
    )
    result = crawler.run()
    Path(args.output).write_text(json.dumps(result, indent=2))
    print(f"\nCrawled {result['pages_crawled']} pages "
          f"in {result['duration_sec']}s "
          f"(backend={result['quantum_backend']}).")
    print(f"Final workspace attention: {result['final_attention']}")
    print(f"Results written to {args.output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
